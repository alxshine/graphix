Programming Assignment 2 
by Schlögl Alexander and Mitterwallner Fabian

To compile just run make.

The scene features a fixed light source, and one that turns with the carousel.

The color components of the light source can be toggled with r,g,b and 1,2,3 respectively.

Furthermore the ambient, diffuse, and specular lighting terms can be toggled on and off using the a,d and s keys.

The program can be exited any time by pressing the 'c' key.
